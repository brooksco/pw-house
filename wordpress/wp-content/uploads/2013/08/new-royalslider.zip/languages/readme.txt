To translate RoyalSlider plugin:

1. Download Poedit if you don't have it on your pc/mac. http://www.poedit.net/

2. Open it, go to "File > New Catalog from pot file" and browse to new-royalslider.pot in this "languages" folder

3. Click ok and name your file "new_royalslider-en_US" (where en_US is your locale, for example for russian it should be new_royalslider-ru_RU)

4. Start translating

Please don't forget that you need to set your locale in wp-config.php, for example:
define('WPLANG', 'en_US');


-------------------------------

I'd gladly pay for qualitative translation in any language 
Please send translations to email diiiimaaaa@gmail.com 

-------------------------------